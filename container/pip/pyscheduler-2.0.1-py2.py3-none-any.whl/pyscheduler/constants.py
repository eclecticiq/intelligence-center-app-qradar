DAY = "day"
DAYS = "{day}s".format(day=DAY)
HOUR = "hour"
HOURS = "{hour}s".format(hour=HOUR)
MINUTE = "minute"
MINUTES = "{minute}s".format(minute=MINUTE)
SECOND = "second"
SECONDS = "{second}s".format(second=SECOND)

EVERY = "every"
UNIT = "unit"
TRIGGER = "trigger"
CRON = "cron"

JOB_SPLIT_CHAR = '.'

# As per provided by Apscheduler. 
# DO NOT CHANGE THESE
STATE_STOPPED = 0
STATE_RUNNING = 1
STATE_PAUSED = 2
