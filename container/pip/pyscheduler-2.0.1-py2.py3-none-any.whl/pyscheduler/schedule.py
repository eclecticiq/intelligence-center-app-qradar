import importlib
from typing import Any, Callable, Dict

from apscheduler.schedulers.background import BackgroundScheduler # type: ignore

from pyscheduler.constants import (CRON, EVERY, JOB_SPLIT_CHAR, STATE_PAUSED,
                                   STATE_STOPPED, TRIGGER, UNIT)

KeyValue = Dict[str, Any]


class Schedule(object):
    """Schdule the process to be run in the background

    :param object: Inherits default python object
    :type object: object
    """
    scheduler: BackgroundScheduler

    def __init__(self) -> None:
        """Initialize the schduler demon in the background
        """
        self.scheduler = BackgroundScheduler(daemon=True)

    def add_job_storage(self, name: str, job_store: str) -> None:
        """Add persistent job storage to the scheduler

        :param name: Name of the job store
        :type name: str
        :param job_store: URL / location of the job store
        :type job_store: str
        """
        self.scheduler.add_jobstore(name, url=job_store)

    def add_configurations(self, jobstores: KeyValue, executors: KeyValue, job_defaults: KeyValue) -> None:
        """Add configurations to include jobstores, executors and job_defaults to the scheduled jobs

        :param jobstores: Job store to be used
        :type jobstores: dict
        :param executors: Executors to be used
        :type executors: dict
        :param job_defaults: Job default configurations to be used
        :type job_defaults: dict
        """
        self.scheduler.configure(jobstores=jobstores, executors=executors, job_defaults=job_defaults)

    def add_jobs(self, jobs: KeyValue) -> None:
        """Add jobs to the scheduler from configurations

        :param jobs: Jobs to be added to the scheduler
        :type jobs: dict
        """
        for func_name, config in jobs.items():
            package_path, function = func_name.rsplit(JOB_SPLIT_CHAR, 1)
            module = importlib.import_module(package_path)
            func = getattr(module, function)

            kwargs = {}

            if EVERY in config:
                kwargs[config[UNIT]] = config[EVERY]
                del config[UNIT]
                del config[EVERY]

            if config[TRIGGER] == CRON:
                del config[UNIT]

            for key, value in config.items():
                kwargs[key] = value

            self.scheduler.add_job(func, **kwargs)
    
    def add_job(self, function: Callable[[KeyValue], Any], schedule: KeyValue) -> None:
        """Add single job to the scheduler

        :param function: Function as object, to be called to schedule a single job
        :type function: object
        :param schedule: Schedule to be executed for the function
        :type schedule: dict
        """
        self.scheduler.add_job(function, **schedule)
    
    def start(self) -> None:
        """Start the configured executors and job stores and begin processing scheduled jobs.
        """
        self.scheduler.start()
    
    def shutdown(self) -> None:
        """Shuts down the scheduler, along with its executors and job processes.
        """
        self.scheduler.shutdown()
    
    def pause(self) -> None:
        """Pause job processing in the scheduler.

        This will prevent the scheduler from waking up to do job processing until resume() is called. 
        It will not however stop any already running job processing.
        """
        self.scheduler.pause()
    
    def resume(self) -> None:
        """Resume job processing in the scheduler.
        """
        self.scheduler.resume()

    def is_running(self) -> bool:
        """Check if scheduler is running or not

        :return: True if running, else False
        :rtype: bool
        """
        return bool(self.scheduler.running)  # OK
    
    def is_paused(self) -> bool:
        """Check if scheduler is paused

        :return: True if paused, else False
        :rtype: bool
        """
        return STATE_PAUSED == int(self.scheduler.state) # OK

    def is_stopped(self) -> bool:
        """Check if the scheduler is stopped

        :return: True if stopped, else False
        :rtype: bool
        """
        return STATE_STOPPED == int(self.scheduler.state) # OK
    
    def is_job_exists(self, job_id: str) -> bool:
        """Look for job if it exists in the jobstore.

        :param job_id: Joib id to be checked to exists in the job store
        :type job_id: str
        :return: True if job exists, else False
        :rtype: bool
        """
        job = self.scheduler.get_job(job_id)
        return job is not None
    
    def get_job(self, job_id: str) -> Any:
        """Get the job specified by job_id. 

        If job exists, it will return job else it will return None

        :param job_id: Job identifier
        :type job_id: str
        :return: Job object / None
        :rtype: object/None
        """
        return self.scheduler.get_job(job_id)
    
    def reschedule(self, job_id: str, schedule: KeyValue) -> None:
        """Reschdule the given job with the new scheduled values provided

        :param job_id: Job to be rescheduled
        :type job_id: str
        :param schedule: New schedule for the job
        :type schedule: dict
        """
        self.scheduler.reschedule_job(job_id, **schedule)

    def remove_job(self, job_id: str) -> None:
        """Removes job if it exists in the scheduler

        :param job_id: Job to be removed
        :type job_id: str
        """
        if self.is_job_exists(job_id):
            self.scheduler.remove_job(job_id)
