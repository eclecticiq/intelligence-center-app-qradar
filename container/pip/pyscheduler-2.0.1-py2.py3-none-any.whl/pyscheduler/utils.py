from typing import Any, Dict, TextIO

import yaml


KeyValue = Dict[str, Any]


def get_yaml_content(filename: str) -> KeyValue:
    """Read the yaml configuration file

    :param filename: YAML configurations file path
    :type filename: str
    :return: List of YAML configurations
    :rtype: dict
    """
    file: TextIO = open(filename)
    schedule_list: KeyValue = yaml.load(file, Loader=yaml.FullLoader)
    file.close()
    return schedule_list


def read_yaml_configurations(filename: str) -> KeyValue:
    """Read YAML configuration and make dictionary of key value pairs

    :param filename: YAML configurations file path
    :type filename: str
    :return: YAML configuration dictionary
    :rtype: dict
    """
    schedule_list: KeyValue = get_yaml_content(filename)
    configurations: KeyValue = {}
    for func_name, docs in schedule_list.items():
        config: KeyValue = {}
        for item in docs:
            for key, value in item.items():
                config[key] = value
        configurations[func_name] = config
    return configurations


