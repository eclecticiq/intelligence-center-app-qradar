"""Http request adapters used to handle requests timeouts."""
