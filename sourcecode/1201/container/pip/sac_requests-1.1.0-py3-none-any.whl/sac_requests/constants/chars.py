"""Character constants."""
EMPTY_STR = ""
COLON_STR = ":"
FORWARDSLASH_STR = "/"

# Regex constants
ENDPOINT_RGX = r"(\/)+$"

# Http URL connector
CONNECTOR = f"{COLON_STR}{FORWARDSLASH_STR}{FORWARDSLASH_STR}"
