"""Constants used in sac request context."""

HTTP = "http"
HTTPS = "https"
AUTHORIZATION = "Authorization"
HEADERS = "headers"
NO_AUTH = "NO_AUTH"  # nosec
BASIC_AUTH = "BASIC_AUTH"  # nosec
BEARER_TOKEN = "BEARER_TOKEN"  # nosec
AUTH = "auth"
AUTH_TYPE = "auth_type"  # nosec
MAX_RETRY = "max_retry"
RETRY_INTERVAL = "retry_interval"
STATUS_FORCE_LIST = "status_force_list"
TIMEOUT = "timeout"
URL = "url"
DATA = "data"
PARAMS = "params"
ENDPOINT = "endpoint"
ERRCODE = "errcode"
MESSAGE = "message"

# Request Types
GET = "get"
HEAD = "head"
POST = "post"
PUT = "put"
DELETE = "delete"
OPTIONS = "options"
PATCH = "patch"

# Http URL connector
CONNECTOR = "://"
