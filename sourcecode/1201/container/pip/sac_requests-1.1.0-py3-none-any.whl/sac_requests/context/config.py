"""Request configurations to use while sending the request over HTTP/HTTPS."""
from typing import Any

from sac_requests.constants.defaults import (DEFAULT_AUTH_TYPE,
                                             DEFAULT_MAX_RETRY,
                                             DEFAULT_RETRY_INTERVAL,
                                             DEFAULT_STATUS_FORCE_LIST,
                                             DEFAULT_TIMEOUT)
from sac_requests.constants.general import (AUTH_TYPE, MAX_RETRY,
                                            RETRY_INTERVAL, STATUS_FORCE_LIST,
                                            TIMEOUT)


class HttpConfig:  # pylint: disable=too-few-public-methods
    """Http Request configurations Holder."""

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the Http Request configurations.

        The configurations include:
        1. Timeout
        2. Retry Interval
        3. Response Status for which to force retry
        4. Maximum retry attempts to make.
        5. Authentication types

        :param kwargs: All configuration params passed as an
        http request initialization.
        """
        self.timeout = kwargs.pop(TIMEOUT, DEFAULT_TIMEOUT)
        self.retry_interval = kwargs.pop(RETRY_INTERVAL, DEFAULT_RETRY_INTERVAL)
        self.status_force_list = kwargs.pop(STATUS_FORCE_LIST, DEFAULT_STATUS_FORCE_LIST)
        self.max_retry = kwargs.pop(MAX_RETRY, DEFAULT_MAX_RETRY)
        self.auth_type = kwargs.pop(AUTH_TYPE, DEFAULT_AUTH_TYPE)
