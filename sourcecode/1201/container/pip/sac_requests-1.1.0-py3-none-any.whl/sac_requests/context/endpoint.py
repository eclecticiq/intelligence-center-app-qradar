"""Manage the endpoint for the URLs.

An endpoint is one end of a communication channel.

Each endpoint is the location from which APIs can access the resources they need to carry out their function.
"""
from sac_requests.utils.general import clean_endpoint


class Endpoint:
    """The endpoint for the API URLs.

    It cleans the endpoint url.
    """

    def __init__(self, endpoint: str) -> None:
        """Initialise the endpoint for the URL.

        :param endpoint: Endpoint string
        :type endpoint: str
        """
        self._endpoint = clean_endpoint(endpoint)

    @property
    def endpoint(self) -> str:
        """Get the endpoint.

        :return: Endpoint for the API.
        :rtype: str
        """
        return self._endpoint

    @endpoint.setter
    def endpoint(self, endpoint_: str) -> None:
        """Set the endpoint.

        :param endpoint_: Set the endpoint for the API.
        :type endpoint_: str
        """
        self._endpoint = clean_endpoint(endpoint_)

    def get(self) -> str:
        """Get the cleaned endpoint.

        :return: Endpoint for URL
        :rtype: str
        """
        return self._endpoint
