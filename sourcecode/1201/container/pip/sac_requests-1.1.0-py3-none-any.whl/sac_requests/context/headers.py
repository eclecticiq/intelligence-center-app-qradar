"""Prepare the Http Request Headers to be sent along with the request.

It can create new headers as well as update the existing headers.
"""
from typing import Any, Optional
from typing import Dict

from sac_requests.constants.messages import INVALID_HEADER_FORMAT


class HttpHeaders:
    """Prepare headers to add to the Http request."""

    def __init__(self, headers: Dict[str, Any]):
        """Initialize the request header.

        :param headers: Request Headers
        :type headers: Dict[str, Any]
        """
        if not headers:
            headers = {}
        if not isinstance(headers, dict):
            raise ValueError(INVALID_HEADER_FORMAT)
        self._headers = headers

    @property
    def headers(self) -> Dict[str, Any]:
        """Get request headers.

        :return: Request headers
        :rtype: Dict[str, Any]
        """
        return self._headers

    @headers.setter
    def headers(self, headers_: Dict[str, Any]) -> None:
        """Set request headers.

        :param headers_: Request Headers
        :type headers_: Dict[str, Any]
        """
        if not headers_:
            headers_ = {}
        self._headers = headers_

    def update(self, headers: Optional[Dict[str, Any]]) -> None:
        """Update the request headers with the new headers.

        It will update the headers which are already present and
        add the headers which did not exists before.

        :param headers: Request Headers to be added
        :type headers: Optional[Dict[str, Any]]
        :raises ValueError: The headers dictionar
        """
        if not headers:
            headers = {}
        if not isinstance(headers, dict):
            raise ValueError(INVALID_HEADER_FORMAT)
        self._headers.update(headers)

    def get(self) -> Dict[str, Any]:
        """Get Http Request Header in key-value pair.

        :return: Http request headers
        :rtype: Dict[str, Any]
        """
        return self.headers
