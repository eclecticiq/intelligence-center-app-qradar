"""Prepare the timeout for http request, in case of server related issues."""
from typing import Any

from requests.adapters import HTTPAdapter  # type: ignore
from requests.models import Request  # type: ignore
from requests.models import Response
from sac_requests.constants.defaults import DEFAULT_TIMEOUT
from sac_requests.constants.general import TIMEOUT


class TimeoutHTTPAdapter(
    HTTPAdapter  # type: ignore
):  # pylint: disable=too-few-public-methods
    """Transport Adapter with default timeouts for http request.

    :param HTTPAdapter: The built-in HTTP Adapter for urllib3.
    :type HTTPAdapter: HTTPAdapter
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialise Timeout http adapter."""
        self.timeout = DEFAULT_TIMEOUT
        if TIMEOUT in kwargs:
            self.timeout = kwargs[TIMEOUT]
            del kwargs[TIMEOUT]
        super().__init__(*args, **kwargs)

    def send(self, request: Request, **kwargs: Any) -> Response:
        """Http request send method.

        :param request: Request object
        :type request: Any
        :return: Http request's response.
        :rtype: Response
        """
        timeout = kwargs.get(TIMEOUT)
        if timeout is None:
            kwargs[TIMEOUT] = self.timeout
        return super().send(request, **kwargs)
