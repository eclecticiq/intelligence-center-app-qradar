"""Exceptions to be raised in http request failure."""
