"""Http request connection failure exception."""
from sac_requests.exceptions.base import HttpRequestError


class HttpRequestConnectionError(HttpRequestError):  # pylint: disable=too-few-public-methods
    """Request Connection Error can be raised when there is a connection error.

    :param ConnectionError: Inherits connection error
    :type ConnectionError: type
    :param HttpRequestError: Inherits HttpRequestError
    :type HttpRequestError: type
    """

    pass
