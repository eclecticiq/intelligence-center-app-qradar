"""Request and Response validators."""
import requests  # type: ignore


def is_success(status_code: int) -> bool:
    """Check if the requests is successful or not.

    :param status_code: Response received via request
    :type status_code: int
    :return: True if response has status code 200/201, else False
    :rtype: bool
    """
    code_list = [requests.codes.okay, requests.codes.created]
    return status_code in code_list


def is_access_denied(status_code: int) -> bool:
    """Check if the status is access denied.

    :param status_code: Response status code
    :type status_code: int
    :return: True if status code is unauthorized else False
    :rtype: bool
    """
    return status_code == requests.codes.unauthorized
